module.export = {
  token: "",
  user: {},
};
